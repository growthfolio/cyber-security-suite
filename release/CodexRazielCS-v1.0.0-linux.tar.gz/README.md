# 🔬 Codex Raziel CS - Cyber Security Research Suite v1.0.0

## Professional Red Team Operations Platform

**⚠️ LEGAL NOTICE: This software is intended EXCLUSIVELY for authorized cybersecurity research, education, and testing in controlled environments.**

### 🎯 What's New in v1.0.0

**🚀 Phase 6: Real Workflow Integration**
- **Real Tool Execution**: Native integration with C/Go cybersecurity tools
- **Intelligent Workflows**: Automated Red Team attack scenarios
- **Result Correlation**: AI-powered analysis across multiple tools
- **Professional UI**: Complete workflow orchestration dashboard

### 🔧 System Requirements

**Java Runtime:**
- Java 17 or higher
- JavaFX runtime (included in most distributions)

**Operating System:**
- Linux (Ubuntu 20.04+, Debian 11+, CentOS 8+)
- Windows 10/11 (with WSL for full functionality)
- macOS 11+ (limited functionality)

**Required Tools (for full functionality):**
```bash
# Network tools
sudo apt install network-manager wireless-tools nmap

# Security tools (optional)
sudo apt install aircrack-ng hydra john hashcat

# Development tools (for native compilation)
sudo apt install gcc make build-essential
```

### 🚀 Quick Start

**1. Download and Run:**
```bash
# Download the JAR file
wget https://github.com/growthfolio/cyber-security-suite/releases/download/v1.0.0/CodexRazielCS-v1.0.0.jar

# Run the application
java -jar CodexRazielCS-v1.0.0.jar
```

**2. First Launch:**
- The application will check system permissions
- Install missing tools as suggested
- Configure network interfaces in Settings

**3. Start Red Team Operations:**
- Navigate to "Red Team Workflows" tab
- Select an attack scenario
- Configure parameters and start workflow
- Monitor real-time execution and results

### 🎯 Available Workflows

**Network Reconnaissance:**
- WiFi network discovery using nmcli/iwlist
- Network vulnerability scanning with nmap
- Target prioritization and selection

**Credential Harvesting:**
- SSH brute force attacks with hydra
- Keylogger deployment (native C implementation)
- Credential extraction and analysis

**Lateral Movement:**
- Privilege escalation techniques
- Persistence establishment
- Network pivoting strategies

**Full Red Team Engagement:**
- Complete 6-step attack chain
- Automated tool coordination
- Comprehensive reporting

### 🔍 Features

**Real Tool Integration:**
- ✅ Native keylogger (C implementation with X11 hooks)
- ✅ Hybrid brute force framework (C+Go)
- ✅ WiFi scanning (nmcli, iwlist integration)
- ✅ Network analysis (nmap integration)

**Intelligent Analysis:**
- ✅ Result correlation across tools
- ✅ Attack path identification
- ✅ Risk assessment generation
- ✅ Context-aware parameter passing

**Professional Interface:**
- ✅ Real-time workflow monitoring
- ✅ Progress visualization
- ✅ Audit logging
- ✅ Export capabilities

### ⚠️ Security Warnings

**IMPORTANT DISCLAIMERS:**
- This tool executes REAL cybersecurity tools
- Only use in authorized environments
- Requires proper permissions and legal authorization
- Monitor all activities through audit logs
- Respect applicable laws and regulations

**Recommended Usage:**
- Isolated lab environments
- Authorized penetration testing
- Cybersecurity education and training
- Red Team exercises with proper approval

### 🐛 Troubleshooting

**Common Issues:**

**"Permission denied" errors:**
```bash
# Add user to required groups
sudo usermod -a -G netdev,wireshark $USER
# Logout and login again
```

**Missing tools:**
```bash
# Install essential tools
sudo apt update
sudo apt install network-manager wireless-tools nmap
```

**JavaFX not found:**
```bash
# Install OpenJFX
sudo apt install openjfx
# Or use Oracle JDK 17+
```

### 📞 Support

**Documentation:** [GitHub Wiki](https://github.com/growthfolio/cyber-security-suite/wiki)
**Issues:** [GitHub Issues](https://github.com/growthfolio/cyber-security-suite/issues)
**Discussions:** [GitHub Discussions](https://github.com/growthfolio/cyber-security-suite/discussions)

### 📄 License

This project is developed for educational and research purposes. Use responsibly and within legal boundaries.

---

**🔬 Professional Cybersecurity Research Platform**
**Built with ❤️ for the cybersecurity community**